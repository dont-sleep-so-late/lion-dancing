import{aE as e,aF as r}from"./index-14661dcc.js";function a(a){return"number"==typeof a||e(a)&&"[object Number]"==r.call(a)}export{a as i};
