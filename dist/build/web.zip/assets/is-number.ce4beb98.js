import{aE as e,aF as r}from"./index-77323780.js";function a(a){return"number"==typeof a||e(a)&&"[object Number]"==r.call(a)}export{a as i};
